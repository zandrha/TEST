package mx.com.zorrito.endpoint;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import mx.com.zorrito.beans.otro.Country;
import mx.com.zorrito.beans.otro.Currency;
import mx.com.zorrito.beans.otro.GetCountryRequest;
import mx.com.zorrito.beans.otro.GetCountryResponse;

@Endpoint
public class CountryEndpoint {
	private static final String NAMESPACE_URI = "http://zorrito.com.mx/beans/otro";

	// private CountryService servicio;

	// @Autowired
	// public CountryEndpoint(CountryService servicio) {
	// this.servicio = servicio;
	// }

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCountryRequest")
	@ResponsePayload
	public GetCountryResponse getCountry(@RequestPayload GetCountryRequest request) {
		System.out.println("Entrada: " + request.getName());

		// Generando la respuesta
		GetCountryResponse response = new GetCountryResponse();
		Country country = new Country();
		country.setCapital(request.getName());
		country.setCurrency(Currency.EUR);
		country.setName("MEXICO");
		country.setPopulation(1234);

		response.setCountry(country);

		return response;
	}
}
